"""Geotechnical stress simulation calculations."""

